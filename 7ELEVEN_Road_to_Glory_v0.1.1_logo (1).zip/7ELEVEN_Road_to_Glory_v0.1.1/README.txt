7ELEVEN: Road to Glory — Versione 0.1

COME AVVIARE
1. Estrai il file ZIP.
2. Apri la cartella.
3. Fai doppio clic su index.html.
4. Il gioco si aprirà nel browser.

FUNZIONI PRESENTI
- Scelta tra moduli 3-2-1, 2-3-1 e 2-1-3
- Rosa completa dei 7ELEVEN
- Selezione titolari con controllo dei ruoli
- Girone unico da 12 squadre
- Prime 8 qualificate ai quarti
- Quarti, semifinale e finale
- Rigori in caso di pareggio nella fase a eliminazione diretta
- Eventi casuali e meme della lore
- Rivalità differenziate
- Cronaca partita
- Salvataggio automatico nel browser
- Hall of Fame locale

NOTA
Il gioco non usa immagini esterne e funziona anche offline.

AGGIORNAMENTO V0.1.1
- Inserito il logo ufficiale 7ELEVEN FC nell'interfaccia principale e nella barra superiore.
