
const PLAYERS = [
  {id:"fae", name:"Fae", roles:["GK"], stars:5, trait:"Si fa ammonire spesso e si attacca con gli avversari.", special:"Nervi tesi"},
  {id:"luca", name:"Luca", roles:["DEF","WING"], stars:5, trait:"Cena di pesce, musica spagnola e tanta tecnica.", special:"Música española"},
  {id:"ledio", name:"Ledio", roles:["DEF","MID"], stars:5, trait:"Espulsioni, garra e corsa infinita.", special:"Garra totale"},
  {id:"caset", name:"Alessandro Caset", roles:["MID"], stars:5, trait:"Nonchalance, sicurezza e ossessione per la Spagna.", special:"Sangue freddo"},
  {id:"lorenzo", name:"Lorenzo Tegani", roles:["ATT"], stars:4, trait:"Non segna nemmeno con le mani, ma si sacrifica sempre.", special:"La porta scappa"},
  {id:"akouete", name:"Leo Akouete", roles:["MID","DEF"], stars:5, trait:"Altezza, corsa, tiro e il misterioso numero 67.", special:"Modalità 67"},
  {id:"bilal", name:"Bilal", roles:["WING"], stars:3, trait:"Esterno rapido e imprevedibile.", special:"Cambio di passo"},
  {id:"pier", name:"Pierfrancesco Tegani", roles:["DEF"], stars:3, trait:"Il capitano. Tiene insieme il gruppo.", special:"Fascia al braccio"},
  {id:"filippo", name:"Filippo Tegani", roles:["DEF"], stars:3, trait:"Difensore ordinato e affidabile.", special:"Linea pulita"},
  {id:"berini", name:"Berini", roles:["DEF"], stars:5, trait:"Il più piccolo e il più forte.", special:"Piccolo gigante"},
  {id:"esseba", name:"Esseba", roles:["MID"], stars:3, trait:"Infortunato da inizio torneo.", special:"Rientro miracoloso"},
  {id:"diego", name:"Diego", roles:["DEF","MID"], stars:4, trait:"Duttilità e sostanza.", special:"Jolly"},
  {id:"thomas", name:"Thomas", roles:["MID"], stars:3, trait:"Il concerto reggaeton viene prima di tutto.", special:"Ritmo latino"}
];

const TEAMS = [
  {name:"7ELEVEN", stars:5, color:"#2f7dff", rivalry:0},
  {name:"Zeus", stars:2, color:"#f4f4f4", rivalry:2},
  {name:"Brutos", stars:4, color:"#60bff2", rivalry:1},
  {name:"Col Picco", stars:4, color:"#d92d37", rivalry:1},
  {name:"Furia 7", stars:5, color:"#7f3fbf", rivalry:2},
  {name:"Wonder Boy", stars:5, color:"#111111", rivalry:4},
  {name:"Piastra", stars:5, color:"#70472f", rivalry:3},
  {name:"Borussia Porkmund", stars:3, color:"#ef78b7", rivalry:1},
  {name:"Infernals", stars:2, color:"#cf2525", rivalry:1},
  {name:"Guardiani del Maneggio", stars:2, color:"#b9875a", rivalry:1},
  {name:"Ruseni", stars:3, color:"#2f8c4a", rivalry:1},
  {name:"Atletico Coca Juniors", stars:2, color:"#f0cf32", rivalry:1}
];

const FORMATIONS = {
  "3-2-1": [["GK"],["DEF","DEF","DEF"],["MID","MID"],["ATT"]],
  "2-3-1": [["GK"],["DEF","DEF"],["MID","MID","MID"],["ATT"]],
  "2-1-3": [["GK"],["DEF","DEF"],["MID"],["WING","ATT","WING"]]
};

const LORE_EVENTS = [
  {text:"Le docce sono gelide. La squadra esce più arrabbiata che riposata.", type:"meme", delta:-1},
  {text:"Scoppia un beef social con gli avversari. La tensione sale.", type:"meme", delta:1},
  {text:"Botte in strada prima del match. Il clima diventa pesantissimo.", type:"card", delta:0},
  {text:"Pizza all'Emanuela: morale alle stelle.", type:"meme", delta:1},
  {text:"Una bestemmia rimbomba in tutta Nogara.", type:"meme", delta:0},
  {text:"Luca tira: la porta non viene nemmeno inquadrata.", type:"meme", delta:0},
  {text:"Lorenzo Tega è solo davanti al portiere. La porta scappa.", type:"meme", delta:0},
  {text:"Il DS mette la birra nelle borracce. +Morale, -precisione.", type:"meme", delta:1},
  {text:"Il Presidente intimorisce gli avversari dal tunnel.", type:"meme", delta:1},
  {text:"Fede fisioterapista rimette in piedi un giocatore in tempo record.", type:"meme", delta:1},
  {text:"Il pallone è sgonfio. L'organizzazione sostiene che sia normale.", type:"meme", delta:0},
  {text:"Il campo sembra un orto. Controllare il pallone diventa facoltativo.", type:"meme", delta:0},
  {text:"L'orario della partita cambia all'ultimo secondo.", type:"meme", delta:-1},
  {text:"Caset entra in campo con la solita nonchalance.", type:"meme", delta:1},
  {text:"Akouete guarda il tabellone: compare il numero 67.", type:"meme", delta:2},
  {text:"Berini vince un contrasto contro uno grande il doppio.", type:"meme", delta:1},
  {text:"Thomas arriva direttamente da un concerto reggaeton.", type:"meme", delta:0},
  {text:"Esseba prova un rientro miracoloso.", type:"meme", delta:1}
];

let state = {
  formation: null,
  selected: [],
  standings: [],
  schedule: [],
  matchday: 0,
  results: [],
  phase: "setup",
  knockout: null,
  currentOpponent: null,
  tournamentStats: {wins:0, draws:0, losses:0, goalsFor:0, goalsAgainst:0, reds:0, yellows:0}
};

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

function showScreen(id){
  $$(".screen").forEach(s => s.classList.remove("active"));
  $("#"+id).classList.add("active");
  window.scrollTo({top:0, behavior:"smooth"});
}
function toast(msg){
  const t=$("#toast"); t.textContent=msg; t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"),1800);
}
function playerOverall(p){ return 55 + p.stars*8 + (p.stars===5?2:0); }
function roleLabel(r){ return ({GK:"POR",DEF:"DIF",MID:"CEN",WING:"EST",ATT:"ATT"})[r]; }
function stars(n){ return "★".repeat(n)+"☆".repeat(5-n); }
function save(){ localStorage.setItem("7e_rtg_save", JSON.stringify(state)); updateContinue(); }
function load(){
  const raw=localStorage.getItem("7e_rtg_save");
  if(!raw) return false;
  try { state=JSON.parse(raw); return true; } catch { return false; }
}
function updateContinue(){
  $("#continueBtn").classList.toggle("hidden", !localStorage.getItem("7e_rtg_save"));
}
function resetGame(){
  localStorage.removeItem("7e_rtg_save");
  state = {
    formation:null, selected:[], standings:[], schedule:[], matchday:0, results:[],
    phase:"setup", knockout:null, currentOpponent:null,
    tournamentStats:{wins:0,draws:0,losses:0,goalsFor:0,goalsAgainst:0,reds:0,yellows:0}
  };
  initSetup();
  showScreen("homeScreen");
  updateContinue();
}

function initSetup(){
  renderFormations();
  renderRoster();
  renderLineup();
}
function renderFormations(){
  const wrap=$("#formationOptions");
  wrap.innerHTML="";
  Object.keys(FORMATIONS).forEach(name=>{
    const div=document.createElement("div");
    div.className="formation-card"+(state.formation===name?" selected":"");
    div.innerHTML=`<strong>${name}</strong><span>7 giocatori • cambi infiniti</span>`;
    div.onclick=()=>{
      state.formation=name;
      state.selected=[];
      const fae=PLAYERS.find(p=>p.id==="fae");
      state.selected.push(fae.id);
      renderFormations(); renderRoster(); renderLineup(); save();
    };
    wrap.appendChild(div);
  });
}
function renderRoster(){
  const wrap=$("#rosterGrid"); wrap.innerHTML="";
  PLAYERS.forEach(p=>{
    const selected=state.selected.includes(p.id);
    const unavailable = !state.formation || (p.id==="fae" && selected);
    const card=document.createElement("article");
    card.className=`player-card ${selected?"selected":""} ${unavailable?"unavailable":""}`;
    card.innerHTML=`
      <div class="player-top">
        <div><div class="player-name">${p.name}</div><div class="roles">${p.roles.map(roleLabel).join(" • ")}</div></div>
        <div class="rating">${stars(p.stars)}</div>
      </div>
      <div class="trait">${p.trait}</div>
      <div class="overall">OVR ${playerOverall(p)} • ${p.special}</div>`;
    if(state.formation && !(p.id==="fae" && selected)){
      card.onclick=()=>togglePlayer(p.id);
    }
    wrap.appendChild(card);
  });
}
function neededCounts(){
  if(!state.formation) return {};
  const counts={GK:0,DEF:0,MID:0,WING:0,ATT:0};
  FORMATIONS[state.formation].flat().forEach(r=>counts[r]++);
  return counts;
}
function selectedRoleCounts(ids=state.selected){
  const counts={GK:0,DEF:0,MID:0,WING:0,ATT:0};
  ids.forEach(id=>{
    const p=PLAYERS.find(x=>x.id===id);
    // assigned greedily later; this count just checks compatibility loosely
    p.roles.forEach(r=>counts[r]++);
  });
  return counts;
}
function canFitSelection(ids){
  if(!state.formation) return false;
  const slots=FORMATIONS[state.formation].flat();
  const players=ids.map(id=>PLAYERS.find(p=>p.id===id));
  if(players.length>7) return false;

  function backtrack(i, remaining){
    if(i===players.length) return true;
    const p=players[i];
    for(let j=0;j<remaining.length;j++){
      if(p.roles.includes(remaining[j])){
        const next=remaining.slice(); next.splice(j,1);
        if(backtrack(i+1,next)) return true;
      }
    }
    return false;
  }
  return backtrack(0, slots.slice());
}
function togglePlayer(id){
  if(state.selected.includes(id)){
    if(id==="fae") return;
    state.selected=state.selected.filter(x=>x!==id);
  } else {
    const candidate=[...state.selected,id];
    if(candidate.length>7) return toast("Hai già scelto 7 titolari.");
    if(!canFitSelection(candidate)) return toast("Questo giocatore non entra nei ruoli rimasti.");
    state.selected=candidate;
  }
  renderRoster(); renderLineup(); save();
}
function assignPlayersToSlots(){
  if(!state.formation) return [];
  const slots=FORMATIONS[state.formation].flat().map((r,i)=>({role:r, idx:i, player:null}));
  const chosen=state.selected.map(id=>PLAYERS.find(p=>p.id===id));
  function solve(pi){
    if(pi===chosen.length) return true;
    for(const slot of slots){
      if(!slot.player && chosen[pi].roles.includes(slot.role)){
        slot.player=chosen[pi];
        if(solve(pi+1)) return true;
        slot.player=null;
      }
    }
    return false;
  }
  solve(0);
  return slots;
}
function renderLineup(){
  const board=$("#lineupBoard");
  const count=state.selected.length;
  $("#lineupCounter").textContent=`${count} / 7`;
  $("#startTournamentBtn").disabled = !(state.formation && count===7 && canFitSelection(state.selected));
  if(!state.formation){
    board.className="lineup-board empty-board"; board.innerHTML="<p>Seleziona un modulo.</p>";
    $("#lineupHelp").textContent="Seleziona un modulo per iniziare."; return;
  }
  $("#lineupHelp").textContent=`Modulo ${state.formation}. Fae è inserito automaticamente in porta.`;
  board.className="lineup-board";
  const assigned=assignPlayersToSlots();
  let cursor=0;
  board.innerHTML="";
  FORMATIONS[state.formation].forEach(row=>{
    const rowDiv=document.createElement("div"); rowDiv.className="line-row";
    row.forEach(role=>{
      const slot=assigned[cursor++];
      const div=document.createElement("div");
      div.className="slot"+(slot.player?" filled":"");
      div.innerHTML=slot.player?`<strong>${slot.player.name}</strong><small>${roleLabel(role)}</small>`:`<strong>${roleLabel(role)}</strong><small>Vuoto</small>`;
      rowDiv.appendChild(div);
    });
    board.appendChild(rowDiv);
  });
}

function initTournament(){
  const table = TEAMS.map(t=>({...t, pts:0, gp:0,w:0,d:0,l:0,gf:0,ga:0}));
  state.standings=table;
  state.schedule=TEAMS.filter(t=>t.name!=="7ELEVEN").map(t=>t.name);
  // deterministic-ish shuffle
  state.schedule.sort(()=>Math.random()-.5);
  state.matchday=0; state.results=[]; state.phase="league";
  state.tournamentStats={wins:0,draws:0,losses:0,goalsFor:0,goalsAgainst:0,reds:0,yellows:0};
  save();
  renderTournament();
  showScreen("tournamentScreen");
}
function renderTournament(){
  if(state.matchday>=state.schedule.length){
    finishLeague(); return;
  }
  const opp=TEAMS.find(t=>t.name===state.schedule[state.matchday]);
  state.currentOpponent=opp.name;
  $("#matchdayPill").textContent=`Giornata ${state.matchday+1} / ${state.schedule.length}`;
  $("#nextMatchCard").innerHTML=matchCardHTML(TEAMS[0],opp);
  const labels=["Bassa","Bassa","Media","Alta","Massima"];
  $("#rivalryTag").textContent=`Rivalità ${labels[opp.rivalry]}`;
  $("#miniLineup").innerHTML=state.selected.map(id=>`<span class="mini-player">${PLAYERS.find(p=>p.id===id).name}</span>`).join("");
  renderStandings();
  renderResults();
  save();
}
function matchCardHTML(a,b){
  return `<div class="next-team"><div class="team-bubble" style="background:${a.color}22;border-color:${a.color}">${a.name.slice(0,3)}</div>${a.name}</div>
  <div class="versus">VS</div>
  <div class="next-team"><div class="team-bubble" style="background:${b.color}22;border-color:${b.color}">${b.name.slice(0,3)}</div>${b.name}</div>`;
}
function renderStandings(){
  const sorted=[...state.standings].sort((a,b)=>b.pts-a.pts || (b.gf-b.ga)-(a.gf-a.ga) || b.gf-a.gf);
  $("#standingsBody").innerHTML=sorted.map((t,i)=>`
    <tr class="${i<8?"qualified":""} ${t.name==="7ELEVEN"?"user-row":""}">
      <td>${i+1}</td><td><b>${t.name}</b></td><td>${t.pts}</td><td>${t.gp}</td>
      <td>${t.w}</td><td>${t.d}</td><td>${t.l}</td><td>${t.gf-t.ga}</td>
    </tr>`).join("");
}
function renderResults(){
  const last=state.results.slice(-8).reverse();
  $("#resultsFeed").innerHTML=last.length?last.map(r=>`<div class="result-row"><span>${r.home} - ${r.away}</span><b>${r.hs} - ${r.as}</b></div>`).join(""):"<p>Nessuna partita giocata.</p>";
}

function teamStrength(){
  const avg=state.selected.reduce((s,id)=>s+playerOverall(PLAYERS.find(p=>p.id===id)),0)/7;
  const chemistry = state.formation ? 3 : 0;
  return avg+chemistry;
}
function simulateGoals(strengthA,strengthB){
  const diff=(strengthA-strengthB)/18;
  const baseA=1.25+diff;
  const baseB=1.15-diff;
  const poisson=lambda=>{
    const L=Math.exp(-Math.max(.15,lambda)); let p=1,k=0;
    do { k++; p*=Math.random(); } while(p>L);
    return k-1;
  };
  return [Math.min(7,poisson(baseA)),Math.min(7,poisson(baseB))];
}
function playCurrentMatch(isKnockout=false){
  const opp=TEAMS.find(t=>t.name===state.currentOpponent);
  $("#opponentName").textContent=opp.name;
  $("#opponentDot").style.background=opp.color;
  $("#homeScore").textContent="0"; $("#awayScore").textContent="0"; $("#matchMinute").textContent="0'";
  $("#commentaryFeed").innerHTML="";
  $("#advanceMatchBtn").textContent="Avvia simulazione";
  $("#advanceMatchBtn").disabled=false;
  $("#advanceMatchBtn").onclick=()=>runMatchSimulation(opp,isKnockout);
  showScreen("matchScreen");
}
function addComment(minute,title,text,type=""){
  const item=document.createElement("div");
  item.className=`commentary-item ${type}`;
  item.innerHTML=`<strong>${minute}' — ${title}</strong><span>${text}</span>`;
  $("#commentaryFeed").appendChild(item);
  $("#commentaryFeed").scrollTop=$("#commentaryFeed").scrollHeight;
}
async function runMatchSimulation(opp,isKnockout){
  $("#advanceMatchBtn").disabled=true;
  const userStr=teamStrength();
  const oppStr=55+opp.stars*8+(opp.rivalry*1.3);
  let [hg,ag]=simulateGoals(userStr,oppStr);
  const events=[];

  // cards and lore
  if(Math.random()<.55){ events.push({m:Math.floor(4+Math.random()*22),t:"Fae protesta",x:"L'arbitro estrae il giallo. Era nell'aria.",type:"card",yellow:1}); }
  if(state.selected.includes("ledio") && Math.random()<.34){ events.push({m:Math.floor(12+Math.random()*32),t:"Ledio entra con la garra",x:"ROSSO DIRETTO. La squadra resta in sei.",type:"card",red:1}); if(Math.random()<.55) ag++; }
  const lore=[...LORE_EVENTS].sort(()=>Math.random()-.5).slice(0,3);
  lore.forEach((e,i)=>events.push({m:Math.floor(5+i*14+Math.random()*10),t:"Evento",x:e.text,type:e.type,delta:e.delta}));

  for(let i=0;i<hg;i++){
    const scorers=state.selected.filter(id=>id!=="fae");
    let scorer=PLAYERS.find(p=>p.id===scorers[Math.floor(Math.random()*scorers.length)]);
    if(scorer.id==="lorenzo" && Math.random()<.55) scorer=PLAYERS.find(p=>p.id==="akouete") || scorer;
    events.push({m:Math.floor(2+Math.random()*48),t:"GOOOL 7ELEVEN",x:`${scorer.name} trova la rete!`,type:"goal",homeGoal:1});
  }
  for(let i=0;i<ag;i++) events.push({m:Math.floor(2+Math.random()*48),t:`Gol ${opp.name}`,x:"La difesa viene sorpresa.",type:"goal",awayGoal:1});
  events.sort((a,b)=>a.m-b.m);

  let shownH=0,shownA=0;
  $("#advanceMatchBtn").textContent="Simulazione in corso...";
  for(const e of events){
    await new Promise(r=>setTimeout(r,270));
    $("#matchMinute").textContent=`${e.m}'`;
    if(e.homeGoal){shownH++;$("#homeScore").textContent=shownH;}
    if(e.awayGoal){shownA++;$("#awayScore").textContent=shownA;}
    if(e.yellow) state.tournamentStats.yellows++;
    if(e.red) state.tournamentStats.reds++;
    addComment(e.m,e.t,e.x,e.type);
  }
  await new Promise(r=>setTimeout(r,320));
  $("#matchMinute").textContent="50'";

  // knockout penalty shootout
  let penalties=null;
  if(isKnockout && hg===ag){
    let ph=3+Math.floor(Math.random()*3), pa=3+Math.floor(Math.random()*3);
    while(ph===pa){ ph=3+Math.floor(Math.random()*4); pa=3+Math.floor(Math.random()*4); }
    penalties=[ph,pa];
    addComment("RIG","Calci di rigore",`7ELEVEN ${ph}-${pa} ${opp.name}`,"meme");
  }

  $("#advanceMatchBtn").textContent="Continua";
  $("#advanceMatchBtn").disabled=false;
  $("#advanceMatchBtn").onclick=()=>completeMatch(opp,hg,ag,isKnockout,penalties);
}
function completeMatch(opp,hg,ag,isKnockout,penalties){
  state.tournamentStats.goalsFor+=hg; state.tournamentStats.goalsAgainst+=ag;
  let userWon = hg>ag || (penalties && penalties[0]>penalties[1]);
  let userLost = hg<ag || (penalties && penalties[0]<penalties[1]);
  if(userWon) state.tournamentStats.wins++; else if(userLost) state.tournamentStats.losses++; else state.tournamentStats.draws++;

  if(!isKnockout){
    applyLeagueResult("7ELEVEN",opp.name,hg,ag);
    simulateOtherLeagueMatches();
    state.results.push({home:"7ELEVEN",away:opp.name,hs:hg,as:ag});
    state.matchday++;
    save();
    renderTournament();
    showScreen("tournamentScreen");
  } else {
    state.knockout.lastResult={opp:opp.name,hg,ag,penalties,userWon};
    if(!userWon){ finishTournament(false, state.knockout.round); return; }
    advanceKnockout();
  }
}
function applyLeagueResult(aName,bName,ag,bg){
  const a=state.standings.find(t=>t.name===aName), b=state.standings.find(t=>t.name===bName);
  [a,b].forEach(t=>t.gp++); a.gf+=ag;a.ga+=bg;b.gf+=bg;b.ga+=ag;
  if(ag>bg){a.w++;a.pts+=3;b.l++;} else if(bg>ag){b.w++;b.pts+=3;a.l++;} else {a.d++;b.d++;a.pts++;b.pts++;}
}
function simulateOtherLeagueMatches(){
  const others=TEAMS.filter(t=>t.name!=="7ELEVEN").sort(()=>Math.random()-.5);
  for(let i=0;i<others.length-1;i+=2){
    const a=others[i],b=others[i+1];
    const [ga,gb]=simulateGoals(55+a.stars*8,55+b.stars*8);
    applyLeagueResult(a.name,b.name,ga,gb);
    state.results.push({home:a.name,away:b.name,hs:ga,as:gb});
  }
}
function finishLeague(){
  const sorted=[...state.standings].sort((a,b)=>b.pts-a.pts || (b.gf-b.ga)-(a.gf-a.ga) || b.gf-a.gf);
  const seed=sorted.findIndex(t=>t.name==="7ELEVEN")+1;
  if(seed>8){ finishTournament(false,"girone"); return; }
  const top8=sorted.slice(0,8);
  const pairs=[[0,7],[1,6],[2,5],[3,4]].map(([a,b])=>[top8[a].name,top8[b].name]);
  const pair=pairs.find(p=>p.includes("7ELEVEN"));
  state.knockout={round:"Quarti di finale",seed,top8:top8.map(t=>t.name),pairs,opponent:pair.find(n=>n!=="7ELEVEN"),history:[]};
  state.currentOpponent=state.knockout.opponent;
  save(); renderKnockout(); showScreen("knockoutScreen");
}
function renderKnockout(){
  $("#knockoutTitle").textContent=state.knockout.round;
  $("#seedPill").textContent=`Seed #${state.knockout.seed}`;
  $("#bracketBoard").innerHTML=state.knockout.pairs.map((p,i)=>`
    <div class="bracket-row">
      <div><span class="seed">SFIDA ${i+1}</span><br><b>${p[0]}</b></div>
      <span>VS</span>
      <div style="text-align:right"><span class="seed">ACCOPPIAMENTO</span><br><b>${p[1]}</b></div>
    </div>`).join("");
  const opp=TEAMS.find(t=>t.name===state.knockout.opponent);
  $("#knockoutMatchCard").innerHTML=matchCardHTML(TEAMS[0],opp);
}
function advanceKnockout(){
  const k=state.knockout;
  k.history.push({...k.lastResult,round:k.round});
  if(k.round==="Quarti di finale"){
    k.round="Semifinale";
    const pool=k.top8.filter(n=>n!=="7ELEVEN" && n!==k.lastResult.opp);
    k.opponent=pool.sort(()=>Math.random()-.5)[0];
    k.pairs=[["7ELEVEN",k.opponent],["Wonder Boy","Piastra"]].map(p=>p[0]===p[1]?["Furia 7","Col Picco"]:p);
  } else if(k.round==="Semifinale"){
    k.round="Finale";
    const pool=TEAMS.filter(t=>t.name!=="7ELEVEN" && t.name!==k.lastResult.opp).sort((a,b)=>b.stars-a.stars);
    k.opponent=pool[Math.floor(Math.random()*Math.min(4,pool.length))].name;
    k.pairs=[["7ELEVEN",k.opponent]];
  } else {
    finishTournament(true,"finale"); return;
  }
  state.currentOpponent=k.opponent;
  save(); renderKnockout(); showScreen("knockoutScreen");
}
function finishTournament(champion,stage){
  state.phase="finished";
  const s=state.tournamentStats;
  const best=JSON.parse(localStorage.getItem("7e_rtg_hof")||"null");
  const score=s.wins*3+s.draws+s.goalsFor-s.goalsAgainst+(champion?20:0);
  if(!best || score>best.score) localStorage.setItem("7e_rtg_hof",JSON.stringify({score,champion,stats:s,date:new Date().toLocaleDateString("it-IT")}));
  $("#finalCard").innerHTML=champion?`
    <div>
      <span class="eyebrow">MISSIONE COMPIUTA</span>
      <h2>CAMPIONI</h2>
      <p>I 7ELEVEN hanno conquistato Notti Magiche. La leggenda è stata scritta tra garra, birra nelle borracce e il numero 67.</p>
      ${finalStatsHTML(s)}
      <div class="counter-pill">🏆 ROAD TO GLORY COMPLETATA</div>
    </div>`:`
    <div>
      <span class="eyebrow">FINE DEL VIAGGIO</span>
      <h2>${stage==="girone"?"ELIMINATI":"QUASI"}</h2>
      <p>Il cammino si ferma ${stage==="girone"?"nel girone unico":`ai ${stage}`}. Ma la lore non finisce qui.</p>
      ${finalStatsHTML(s)}
      <div class="counter-pill">La vendetta è già iniziata.</div>
    </div>`;
  save(); showScreen("finalScreen");
}
function finalStatsHTML(s){
  return `<div class="final-stats">
    <div class="final-stat"><b>${s.wins}</b><br>Vittorie</div>
    <div class="final-stat"><b>${s.goalsFor}</b><br>Gol fatti</div>
    <div class="final-stat"><b>${s.reds}</b><br>Rossi</div>
    <div class="final-stat"><b>${s.yellows}</b><br>Gialli</div>
  </div>`;
}
function resumeGame(){
  if(!load()) return;
  initSetup();
  if(state.phase==="league"){renderTournament();showScreen("tournamentScreen");}
  else if(state.knockout && state.phase!=="finished"){renderKnockout();showScreen("knockoutScreen");}
  else if(state.phase==="finished"){showScreen("finalScreen");}
  else showScreen("setupScreen");
}

$("#newGameBtn").onclick=()=>{ resetGame(); showScreen("setupScreen"); };
$("#continueBtn").onclick=resumeGame;
$("#resetBtn").onclick=()=>{ if(confirm("Vuoi cancellare il salvataggio?")) resetGame(); };
$("#startTournamentBtn").onclick=initTournament;
$("#playMatchBtn").onclick=()=>playCurrentMatch(false);
$("#playKnockoutBtn").onclick=()=>playCurrentMatch(true);
$("#changeLineupBtn").onclick=()=>{ showScreen("setupScreen"); };
$("#restartBtn").onclick=()=>{ resetGame(); showScreen("setupScreen"); };
$$("[data-back]").forEach(b=>b.onclick=()=>showScreen(b.dataset.back));

initSetup();
updateContinue();
